# FreshDrop V2 — free setup

## What this version does
- Customer product store
- Search + categories
- Cart
- Real order creation when Supabase is connected
- Admin email/password login when Supabase is connected
- Admin order inbox + status updates
- Admin product add/delete/stock controls
- Browser-only demo fallback when Supabase is not configured

## 1. Create the free backend
Create a Supabase project, then open SQL Editor and run `supabase-schema.sql`.

## 2. Create an admin account
In Supabase Authentication, create an Email/Password user for the business owner.

## 3. Connect the website
Open `index.html` and set:

`SUPABASE_URL = 'your-project-url'`
`SUPABASE_ANON_KEY = 'your-anon-public-key'`

Use the project's public anon/publishable key only. Never use a service_role/secret key in this file.

## 4. Deploy
Upload `index.html` to the root of the GitHub Pages repository. Supabase works with a static GitHub Pages frontend.

## Demo login before Supabase
Email: `admin@freshdrop.local`
Password: `freshdrop`

This demo login is only local to the browser and is NOT secure enough for a real business deployment.

## Important production work still needed
- Stronger admin authorization/role table
- Customer order-status lookup tied to an order/customer identity
- Real product images/storage
- Payment integration if required
- Delivery zones/fees
- Notifications/WhatsApp integration if required
- Input validation, rate limiting and abuse protection
- Privacy/terms pages
- Final testing with the business owner
